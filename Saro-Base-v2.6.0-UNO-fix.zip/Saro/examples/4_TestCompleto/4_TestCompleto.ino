// Test sequenziale SARO - Arduino UNO
#include <Saro.h>

inizia() {
  aspetta(2);

  avanti(1);
  indietro(1);
  passo();
  destra(0.5);
  sinistra(0.5);

  lascia(1);  // apre: D9 HIGH, D10 LOW
  prendi(1);  // chiude: D9 LOW, D10 HIGH

  su(1.2);
  giu(1.2);

  fermaTutto();
}
