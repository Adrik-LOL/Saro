#include <Saro.h>

inizia() {
  lascia(1.0);
  aspetta(1);
  prendi(1.0);
  fermaPinza();
}
