#include <Saro.h>

inizia() {
  avanti(1);
  indietro(1);
  destra(0.5);
  sinistra(0.5);
  ferma();
}
