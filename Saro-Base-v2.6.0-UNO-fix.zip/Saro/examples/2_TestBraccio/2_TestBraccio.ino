// Test/calibrazione servo continuo 360° su D3
#include <Saro.h>

inizia() {
  // Esempio: sostituire 1500 con il neutro reale misurato sul proprio servo.
  saro.impostaImpulsiServo(1500, 2000, 1000);

  su(0.5);
  aspetta(1);
  giu(0.5);
  fermaBraccio();
}
