# Libreria SARO v2.6.0 - Arduino UNO

## Installazione
1. Rimuovere le vecchie copie della libreria `Saro` dalla cartella `libraries`.
2. Riavviare Arduino IDE.
3. Installare questo ZIP da Sketch > Include Library > Add .ZIP Library.
4. Selezionare Arduino UNO.

## Pin previsti
- Ruote: D2, D4, D5, D6
- Pinza (ingressi L298N): D9 e D10
- Servo continuo del braccio: segnale D3

## Comandi
- `avanti(secondi)`, `indietro(secondi)`, `destra(secondi)`, `sinistra(secondi)`, `passo(secondi)`
- `apriPinza(secondi)` / `lascia(secondi)`
- `chiudiPinza(secondi)` / `prendi(secondi)`
- `su(secondi)`, `giu(secondi)`
- `ferma()`, `fermaPinza()`, `fermaBraccio()`, `fermaTutto()`
- `aspetta(secondi)`

`inizia() { ... }` esegue il blocco una sola volta in `setup()`.
`ripeti() { ... }` esegue il blocco continuamente in `loop()`.

## Importante: servo continuo
I valori 1500/2000/1000 us sono valori iniziali, non una calibrazione garantita.
Un servo a rotazione continua può avere il neutro reale, per esempio, a 1475 o 1520 us.
Se il braccio non si ferma o si muove lentamente al neutro, calibrare con
`impostaImpulsiServo(stopUs, suUs, giuUs)`.

## Importante: Arduino UNO e Timer1
La libreria Servo usa Timer1 su Arduino UNO. D9 e D10 possono essere usati come
uscite digitali `digitalWrite`, come fa questa libreria. Non usare `analogWrite`
su D9 o D10 mentre il servo è gestito dalla libreria Servo.

## Alimentazione e cablaggio
Il servo e i motori non devono essere alimentati dal pin 5V di Arduino se assorbono
corrente elevata. Usare un'alimentazione adeguata ai componenti e collegare le masse
(GND) in comune. Verificare il cablaggio e la corrente del driver prima delle prove.

I comandi temporizzati sono bloccanti: durante `su(1.2)` o `prendi(1.0)` il programma
attende il tempo indicato. La libreria non ripete autonomamente i comandi; se una
sequenza è dentro `ripeti()`, verrà eseguita a ogni iterazione di `loop()`.

## Limiti
La libreria non dispone di finecorsa o encoder. La posizione del braccio e l'apertura
della pinza sono quindi controllate a tempo, non misurate. Per movimenti ripetibili
servono calibrazione e, se necessario, finecorsa/sensori.
