/*
  Saro.cpp - Implementazione SARO v2.6.0
*/
#define SARO_CPP_INTERNAL
#include "Saro.h"
#include <math.h>
#include <limits.h>

Saro saro;

Saro::Saro()
  : _inizializzato(false),
    _usStop(SARO_SERVO_STOP),
    _usSu(SARO_SERVO_SU),
    _usGiu(SARO_SERVO_GIU) {}

void Saro::_attendi(float secondi) {
  // Ignora tempi nulli, negativi, NaN e infiniti.
  if (!isfinite(secondi) || secondi <= 0.0f) return;

  double ms = (double)secondi * 1000.0;
  if (ms > (double)ULONG_MAX) ms = (double)ULONG_MAX;
  delay((unsigned long)(ms + 0.5));
}

void Saro::_assicuraInizio() {
  if (!_inizializzato) avvia();
}

void Saro::avvia() {
  if (_inizializzato) return;

  pinMode(SARO_PIN_IN1, OUTPUT);
  pinMode(SARO_PIN_IN2, OUTPUT);
  pinMode(SARO_PIN_IN3, OUTPUT);
  pinMode(SARO_PIN_IN4, OUTPUT);
  pinMode(SARO_PIN_PINZA_IN3, OUTPUT);
  pinMode(SARO_PIN_PINZA_IN4, OUTPUT);

  // Imposta subito tutte le uscite motore a LOW.
  digitalWrite(SARO_PIN_IN1, LOW);
  digitalWrite(SARO_PIN_IN2, LOW);
  digitalWrite(SARO_PIN_IN3, LOW);
  digitalWrite(SARO_PIN_IN4, LOW);
  digitalWrite(SARO_PIN_PINZA_IN3, LOW);
  digitalWrite(SARO_PIN_PINZA_IN4, LOW);

  // Imposta prima il flag: evita richiami ricorsivi durante l'avvio.
  _inizializzato = true;

  // Servo.h usa Timer1 su UNO. D9/D10 sono usati solo come uscite digitali:
  // NON usare analogWrite() su D9/D10 mentre Servo è attivo.
  _servo.attach(SARO_PIN_SERVO, 500, 2500);
  _servo.writeMicroseconds(_usStop);
  delay(300); // lascia stabilizzare il servo continuo sul neutro
}

void Saro::_motore(uint8_t pinA, uint8_t pinB, int dir, bool inverti) {
  if (inverti) dir = -dir;

  // Prima porta entrambi gli ingressi a LOW, poi imposta la direzione.
  digitalWrite(pinA, LOW);
  digitalWrite(pinB, LOW);

  if (dir > 0) {
    digitalWrite(pinA, HIGH);
  } else if (dir < 0) {
    digitalWrite(pinB, HIGH);
  }
}

void Saro::_ruote(int dirSx, int dirDx, float secondi) {
  _assicuraInizio();
  _motore(SARO_PIN_IN1, SARO_PIN_IN2, dirSx, SARO_INVERTI_SINISTRA);
  _motore(SARO_PIN_IN3, SARO_PIN_IN4, dirDx, SARO_INVERTI_DESTRA);
  _attendi(secondi);
  ferma();
}

void Saro::avanti(float s)   { _ruote(+1, +1, s); }
void Saro::indietro(float s) { _ruote(-1, -1, s); }
void Saro::destra(float s)   { _ruote(+1, -1, s); }
void Saro::sinistra(float s) { _ruote(-1, +1, s); }
void Saro::passo(float s)    { _ruote(+1, +1, s); }

void Saro::ferma() {
  _assicuraInizio();
  digitalWrite(SARO_PIN_IN1, LOW);
  digitalWrite(SARO_PIN_IN2, LOW);
  digitalWrite(SARO_PIN_IN3, LOW);
  digitalWrite(SARO_PIN_IN4, LOW);
}

void Saro::_comandaPinza(bool apri) {
  // Stop elettrico prima di cambiare direzione (L298N).
  digitalWrite(SARO_PIN_PINZA_IN3, LOW);
  digitalWrite(SARO_PIN_PINZA_IN4, LOW);
  delay(SARO_PINZA_TEMPO_INVERSIONE_MS);

  const bool in3High = apri
    ? (SARO_PINZA_APRE_IN3_HIGH != 0)
    : (SARO_PINZA_APRE_IN3_HIGH == 0);

  digitalWrite(SARO_PIN_PINZA_IN3, in3High ? HIGH : LOW);
  digitalWrite(SARO_PIN_PINZA_IN4, in3High ? LOW : HIGH);
}

void Saro::apriPinza(float s) {
  _assicuraInizio();
  if (!isfinite(s) || s <= 0.0f) { fermaPinza(); return; }
  _comandaPinza(true);
  _attendi(s);
  fermaPinza();
}

void Saro::chiudiPinza(float s) {
  _assicuraInizio();
  if (!isfinite(s) || s <= 0.0f) { fermaPinza(); return; }
  _comandaPinza(false);
  _attendi(s);
  fermaPinza();
}

void Saro::lascia(float s) { apriPinza(s); }
void Saro::prendi(float s) { chiudiPinza(s); }

void Saro::fermaPinza() {
  _assicuraInizio();
  digitalWrite(SARO_PIN_PINZA_IN3, LOW);
  digitalWrite(SARO_PIN_PINZA_IN4, LOW);
}

void Saro::_muoviBraccio(int impulso, float secondi) {
  _assicuraInizio();

  if (!isfinite(secondi) || secondi <= 0.0f) {
    fermaBraccio();
    return;
  }

  if (!_servo.attached()) {
    _servo.attach(SARO_PIN_SERVO, 500, 2500);
    _servo.writeMicroseconds(_usStop);
    delay(250); // stabilizza il neutro prima di impartire il movimento
  }

  _servo.writeMicroseconds(impulso);
  _attendi(secondi);
  fermaBraccio();
}

void Saro::su(float s) { _muoviBraccio(_usSu, s); }
void Saro::giu(float s) { _muoviBraccio(_usGiu, s); }

void Saro::fermaBraccio() {
  _assicuraInizio();
  if (_servo.attached()) {
    _servo.writeMicroseconds(_usStop);
    delay(100);
  }
}

void Saro::aspetta(float s) {
  _assicuraInizio();
  _attendi(s);
}

void Saro::fermaTutto() {
  _assicuraInizio();
  ferma();
  fermaPinza();
  fermaBraccio();
}

bool Saro::impostaImpulsiServo(int stopUs, int suUs, int giuUs) {
  if (stopUs < 500 || stopUs > 2500 ||
      suUs < 500 || suUs > 2500 ||
      giuUs < 500 || giuUs > 2500 ||
      suUs == giuUs || stopUs == suUs || stopUs == giuUs) {
    return false;
  }

  _usStop = stopUs;
  _usSu = suUs;
  _usGiu = giuUs;

  if (_servo.attached()) {
    _servo.writeMicroseconds(_usStop);
    delay(100);
  }
  return true;
}
