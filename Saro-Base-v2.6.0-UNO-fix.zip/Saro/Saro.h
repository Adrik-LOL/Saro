/*
  Saro.h - Libreria SARO v2.6.0
  Target: Arduino UNO / ATmega328P
*/
#ifndef SARO_H
#define SARO_H

#include <Arduino.h>
#include <Servo.h>

// Pin motori ruote
#define SARO_PIN_IN1 2
#define SARO_PIN_IN2 4
#define SARO_PIN_IN3 5
#define SARO_PIN_IN4 6

// L298N pinza: ingressi collegati a D9 e D10
#define SARO_PIN_PINZA_IN3 9
#define SARO_PIN_PINZA_IN4 10

// Segnale servo continuo 360°
#define SARO_PIN_SERVO 3

// Verso ruote
#define SARO_INVERTI_SINISTRA 1
#define SARO_INVERTI_DESTRA   1

// Apertura pinza verificata con il test elettrico: D9 HIGH, D10 LOW
#define SARO_PINZA_APRE_IN3_HIGH 1

// Impulsi iniziali servo continuo (da calibrare sul singolo esemplare)
#define SARO_SERVO_STOP 1500
#define SARO_SERVO_SU   2000
#define SARO_SERVO_GIU  1000

// Tempo minimo tra stop e inversione della pinza (ms)
#define SARO_PINZA_TEMPO_INVERSIONE_MS 40

class Saro {
  public:
    Saro();
    void avvia();

    void avanti(float secondi = 1.0f);
    void indietro(float secondi = 1.0f);
    void destra(float secondi = 0.5f);
    void sinistra(float secondi = 0.5f);
    void passo(float secondi = 0.8f);
    void ferma();

    void apriPinza(float secondi = 0.8f);
    void chiudiPinza(float secondi = 0.8f);
    void lascia(float secondi = 0.8f); // alias apertura
    void prendi(float secondi = 0.8f); // alias chiusura
    void fermaPinza();

    void su(float secondi = 1.2f);
    void giu(float secondi = 1.2f);
    void fermaBraccio();

    void aspetta(float secondi = 1.0f);
    void fermaTutto();

    // Restituisce false se gli impulsi sono fuori intervallo o incoerenti.
    bool impostaImpulsiServo(int stopUs, int suUs, int giuUs);

  private:
    Servo _servo;
    bool _inizializzato;
    int _usStop;
    int _usSu;
    int _usGiu;

    void _assicuraInizio();
    void _attendi(float secondi);
    void _motore(uint8_t pinA, uint8_t pinB, int dir, bool inverti);
    void _ruote(int dirSx, int dirDx, float secondi);
    void _comandaPinza(bool apri);
    void _muoviBraccio(int impulso, float secondi);
};

extern Saro saro;

inline void avanti(float s = 1.0f) { saro.avanti(s); }
inline void indietro(float s = 1.0f) { saro.indietro(s); }
inline void destra(float s = 0.5f) { saro.destra(s); }
inline void sinistra(float s = 0.5f) { saro.sinistra(s); }
inline void passo(float s = 0.8f) { saro.passo(s); }
inline void ferma() { saro.ferma(); }
inline void stop() { saro.ferma(); }

inline void apriPinza(float s = 0.8f) { saro.apriPinza(s); }
inline void chiudiPinza(float s = 0.8f) { saro.chiudiPinza(s); }
inline void lascia(float s = 0.8f) { saro.lascia(s); }
inline void prendi(float s = 0.8f) { saro.prendi(s); }
inline void fermaPinza() { saro.fermaPinza(); }

inline void su(float s = 1.2f) { saro.su(s); }
inline void giu(float s = 1.2f) { saro.giu(s); }
inline void fermaBraccio() { saro.fermaBraccio(); }
inline void aspetta(float s = 1.0f) { saro.aspetta(s); }
inline void fermaTutto() { saro.fermaTutto(); }

// inizia(): esegue il blocco una sola volta in setup()
// ripeti(): esegue il blocco continuamente in loop()
#ifndef SARO_CPP_INTERNAL
#define inizia() void loop() {} void setup()
#define ripeti() void setup() {} void loop()
#endif

#endif
