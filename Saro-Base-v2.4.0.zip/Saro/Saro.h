/*
  Saro.h - Versione base essenziale per bambini (Arduino UNO)
  Pinza corretta sui pin D9 e D10 (Driver L298N).
*/
#ifndef SARO_H
#define SARO_H

#include <Arduino.h>
#include <Servo.h>

// ---------------------------------------------------------------
// PIN (collegamenti del robot)
// ---------------------------------------------------------------
#define SARO_PIN_IN1 2
#define SARO_PIN_IN2 4
#define SARO_PIN_IN3 5
#define SARO_PIN_IN4 6

// Pinza sul secondo L298N (IN3/IN4 collegati a D9 e D10)
#define SARO_PIN_PINZA_IN3 9
#define SARO_PIN_PINZA_IN4 10

#define SARO_PIN_SERVO 3

// ---------------------------------------------------------------
// INVERSIONE DIREZIONI (1 = inverti, 0 = normale)
// ---------------------------------------------------------------
#define SARO_INVERTI_SINISTRA 1
#define SARO_INVERTI_DESTRA   1
#define SARO_INVERTI_PINZA    1

// ---------------------------------------------------------------
// VALORI DEL SERVO 8135MG 360° (in microsecondi)
// ---------------------------------------------------------------
#define SARO_SERVO_STOP 1500
#define SARO_SERVO_SU   2000
#define SARO_SERVO_GIU  1000
#define SARO_SERVO_STACCA_A_FERMO 0

class Saro {
  public:
    Saro();

    void avvia();

    // Ruote base
    void avanti(float secondi = 1.0);
    void indietro(float secondi = 1.0);
    void destra(float secondi = 0.5);
    void sinistra(float secondi = 0.5);
    void passo(float secondi = 0.8);
    void ferma();

    // Pinza base (su D9 e D10)
    void prendi(float secondi = 0.8);
    void lascia(float secondi = 0.8);
    void fermaPinza();

    // Braccio base (su D3)
    void su(float secondi = 1.2);
    void giu(float secondi = 1.2);
    void fermaBraccio();

    // Attesa
    void aspetta(float secondi = 1.0);

    // Calibrazione avanzata (per adulti)
    void impostaImpulsiServo(int stop, int su, int giu);

  private:
    Servo _servo;
    bool _inizializzato;
    int _usStop;
    int _usSu;
    int _usGiu;

    void _assicuraInizio();
    void _ruote(int dirSx, int dirDx, float secondi);
    void _attendi(float secondi);
    void _motore(uint8_t pinA, uint8_t pinB, int dir, bool inverti);
};

extern Saro saro;

// ---------------------------------------------------------------
// COMANDI BASE DIRETTI
// ---------------------------------------------------------------
inline void avanti(float s = 1.0)   { saro.avanti(s); }
inline void indietro(float s = 1.0) { saro.indietro(s); }
inline void destra(float s = 0.5)   { saro.destra(s); }
inline void sinistra(float s = 0.5) { saro.sinistra(s); }
inline void passo(float s = 0.8)    { saro.passo(s); }
inline void ferma()                 { saro.ferma(); }
inline void stop()                  { saro.ferma(); }

inline void su(float s = 1.2)       { saro.su(s); }
inline void giu(float s = 1.2)      { saro.giu(s); }

inline void prendi(float s = 0.8)   { saro.prendi(s); }
inline void lascia(float s = 0.8)   { saro.lascia(s); }

inline void aspetta(float s = 1.0)  { saro.aspetta(s); }

// Struttura semplificata per lo sketch
#ifndef SARO_CPP_INTERNAL
#define inizia() void loop() {} void setup()
#define ripeti() void setup() {} void loop()
#endif

#endif
