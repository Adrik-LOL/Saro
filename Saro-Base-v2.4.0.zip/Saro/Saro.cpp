/*
  Saro.cpp - Implementazione base per il robot SARO
*/
#define SARO_CPP_INTERNAL
#include "Saro.h"

Saro saro;

void Saro::_attendi(float secondi) {
  if (secondi < 0) secondi = 0;
  delay((unsigned long)(secondi * 1000.0));
}

Saro::Saro() {
  _inizializzato = false;
  _usStop = SARO_SERVO_STOP;
  _usSu   = SARO_SERVO_SU;
  _usGiu  = SARO_SERVO_GIU;
}

void Saro::_assicuraInizio() {
  if (!_inizializzato) {
    avvia();
  }
}

void Saro::avvia() {
  if (_inizializzato) return;

  pinMode(SARO_PIN_IN1, OUTPUT);
  pinMode(SARO_PIN_IN2, OUTPUT);
  pinMode(SARO_PIN_IN3, OUTPUT);
  pinMode(SARO_PIN_IN4, OUTPUT);

  pinMode(SARO_PIN_PINZA_IN3, OUTPUT);
  pinMode(SARO_PIN_PINZA_IN4, OUTPUT);

  _inizializzato = true;

  ferma();
  fermaPinza();

  _servo.attach(SARO_PIN_SERVO, 500, 2500);
  _servo.writeMicroseconds(_usStop);
  delay(50);
#if SARO_SERVO_STACCA_A_FERMO
  _servo.detach();
#endif
}

void Saro::_motore(uint8_t pinA, uint8_t pinB, int dir, bool inverti) {
  if (inverti) dir = -dir;
  digitalWrite(pinA, dir > 0 ? HIGH : LOW);
  digitalWrite(pinB, dir < 0 ? HIGH : LOW);
}

void Saro::_ruote(int dirSx, int dirDx, float secondi) {
  _assicuraInizio();
  _motore(SARO_PIN_IN1, SARO_PIN_IN2, dirSx, SARO_INVERTI_SINISTRA);
  _motore(SARO_PIN_IN3, SARO_PIN_IN4, dirDx, SARO_INVERTI_DESTRA);
  _attendi(secondi);
  ferma();
}

void Saro::avanti(float secondi)   { _ruote(+1, +1, secondi); }
void Saro::indietro(float secondi) { _ruote(-1, -1, secondi); }
void Saro::destra(float secondi)   { _ruote(+1, -1, secondi); }
void Saro::sinistra(float secondi) { _ruote(-1, +1, secondi); }
void Saro::passo(float secondi)    { _ruote(+1, +1, secondi); }

void Saro::ferma() {
  _assicuraInizio();
  digitalWrite(SARO_PIN_IN1, LOW);
  digitalWrite(SARO_PIN_IN2, LOW);
  digitalWrite(SARO_PIN_IN3, LOW);
  digitalWrite(SARO_PIN_IN4, LOW);
}

void Saro::prendi(float secondi) {
  _assicuraInizio();
  _motore(SARO_PIN_PINZA_IN3, SARO_PIN_PINZA_IN4, +1, SARO_INVERTI_PINZA);
  _attendi(secondi);
  fermaPinza();
}

void Saro::lascia(float secondi) {
  _assicuraInizio();
  _motore(SARO_PIN_PINZA_IN3, SARO_PIN_PINZA_IN4, -1, SARO_INVERTI_PINZA);
  _attendi(secondi);
  fermaPinza();
}

void Saro::fermaPinza() {
  _assicuraInizio();
  digitalWrite(SARO_PIN_PINZA_IN3, LOW);
  digitalWrite(SARO_PIN_PINZA_IN4, LOW);
}

void Saro::su(float secondi) {
  _assicuraInizio();
  if (!_servo.attached()) {
    _servo.attach(SARO_PIN_SERVO, 500, 2500);
    delay(20);
  }
  _servo.writeMicroseconds(_usSu);
  _attendi(secondi);
  fermaBraccio();
}

void Saro::giu(float secondi) {
  _assicuraInizio();
  if (!_servo.attached()) {
    _servo.attach(SARO_PIN_SERVO, 500, 2500);
    delay(20);
  }
  _servo.writeMicroseconds(_usGiu);
  _attendi(secondi);
  fermaBraccio();
}

void Saro::fermaBraccio() {
  _assicuraInizio();
  if (_servo.attached()) {
    _servo.writeMicroseconds(_usStop);
    delay(40);
#if SARO_SERVO_STACCA_A_FERMO
    _servo.detach();
#endif
  }
}

void Saro::aspetta(float secondi) {
  _assicuraInizio();
  _attendi(secondi);
}

void Saro::impostaImpulsiServo(int stop, int su, int giu) {
  _usStop = stop;
  _usSu   = su;
  _usGiu  = giu;
}
