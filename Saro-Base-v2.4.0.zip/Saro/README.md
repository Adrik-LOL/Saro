# SARO - Libreria Base con Esempi di Test

Libreria con comandi base in italiano e pinza configurata sui pin **D9 e D10**.

## Esempi inclusi (File -> Esempi -> Saro):
1. **1_TestRuote**: prova avanti, indietro, passo, destra, sinistra.
2. **2_TestBraccio**: prova le funzioni `su()` e `giu()` del braccio su **D3**.
3. **3_TestPinza**: prova le funzioni `prendi()` e `lascia()` della pinza su **D9 e D10**.
4. **4_TestCompleto**: esegue in sequenza tutte le funzioni della libreria.
