// Test di tutte le funzioni della PINZA (su D9 e D10)
#include <Saro.h>

inizia() {
  aspetta(2);
  lascia(1.2);     // Apre la pinza
  aspetta(1);
  prendi(1.2);     // Chiude la pinza
}
