// Test completo di ogni singola funzione del robot SARO
#include <Saro.h>

inizia() {
  aspetta(2);

  // 1. Ruote
  avanti(1);
  indietro(1);
  passo();
  destra(0.5);
  sinistra(0.5);

  // 2. Pinza (D9 e D10)
  lascia(1);
  prendi(1);

  // 3. Braccio (D3)
  su(1.2);
  giu(1.2);

  // 4. Pausa e Stop
  aspetta(1);
  ferma();
}
