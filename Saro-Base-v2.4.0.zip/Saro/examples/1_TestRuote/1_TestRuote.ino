// Test di tutte le funzioni delle RUOTE
#include <Saro.h>

inizia() {
  aspetta(2);      // Tempo per mettere a terra il robot
  avanti(1.5);     // Va avanti
  aspetta(1);
  indietro(1.5);   // Va indietro
  aspetta(1);
  passo();         // Fa un passo avanti standard
  aspetta(1);
  destra(0.8);     // Gira a destra
  aspetta(1);
  sinistra(0.8);   // Gira a sinistra
}
