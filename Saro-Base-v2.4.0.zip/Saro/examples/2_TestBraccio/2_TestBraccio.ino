// Test di tutte le funzioni del BRACCIO (su D3)
#include <Saro.h>

inizia() {
  aspetta(2);
  su(1.5);         // Alza il braccio per 1.5 secondi
  aspetta(1);
  giu(1.5);        // Abbassa il braccio per 1.5 secondi
}
